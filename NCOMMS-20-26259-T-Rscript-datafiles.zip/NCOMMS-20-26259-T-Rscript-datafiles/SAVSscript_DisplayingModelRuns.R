rm(list=ls())
ls()

## Plot model with specified parameters, and plot original data

library(mosaic)
library(pomp)
library(tibble)
library(ggplot2)

setwd('/Users/hwilliam/Papers/Modeling Savs') # Path to working directory - change for your setup

# Table setup: year/standards/both/variants/total
birdy <- read.csv("IntroType.csv")

# Number of years of lead time to run out transients. (50 is arbitrary, high estimate)
tranyears = 50 
q=length(birdy$year)

# Modify 'year' column to be no. years from start of simulation (set as year 0)
for (l in 1:q){
  birdy$year[l] <- (birdy$year[l]-1980)+tranyears } 

# Set up matrices to collect the model runs
StandardRuns=matrix(c(1980,1982,1989,1993,1994,1995,1996,1997,1998,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013))
VariantRuns=matrix(c(1980,1982,1989,1993,1994,1995,1996,1997,1998,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013))
BothRuns=matrix(c(1980,1982,1989,1993,1994,1995,1996,1997,1998,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013))

# Set  parameters
selection = 1.71
bias = 0.99
immigrants = 2
# setting give_log = 1 causes dbinom to return log likelhoods, not just likelihoods (when give_log = 0)
give_log <- 1

ll = 0

## Presets for simulation: fixed parameters, necessary data structures, etc.
# Estimated population of males on Kent Island study site
num_birds = 70 

# Original proportion of standard-singers on study site
init = 1 

  for (j in 1:50){
    print(j)
      
      # Set initial parameters 
      pars <- c(
        s=0.48, b=selection, n=bias, im=immigrants,
        JSS.0=0, JSV.0=0, JVV.0=0, ASS.0=round(num_birds*init), ASV.0 = 0, AVV.0=round(num_birds-(num_birds*init)))
      
# For S-SV-V, single trait with "both" birds counting twice:
#      double x2 = (ASV+ASS)/((2*ASV)+AVV+ASS);
#      double y2 = (AVV+ASV)/((2*ASV)+AVV+ASS);
      
# For SS-SV-VV, two traits with "both" birds singing half doses of S and of V ...  
#      double x2 = (ASV+(2*ASS))/(2*(ASS+AVV+ASV));      
#      double y2 = ((2*AVV)+ASV)/(2*(ASS+AVV+ASV));

# for ASV immigrants (both click train and high not cluster), use:
#        AVV=round((pow(1-phiS,2)*JSS)+((1-phiS)*phiV*JSV)+(pow(phiV,2)*JVV)+(rbinom(AVV,s)));
#        if (t==53){
#            ASS=round((pow(phiS,2)*JSS)+(phiS*(1-phiV)*JSV)+(pow(1-phiV,2)*JVV)+(rbinom(ASS,s)))-im;
#            ASV=im;
#          } 
#          else{
#            ASS=round((pow(phiS,2)*JSS)+(phiS*(1-phiV)*JSV)+(pow(1-phiV,2)*JVV)+(rbinom(ASS,s)));
#            ASV=round((2*phiS*(1-phiS)*JSS)+(((phiS*phiV)+((1-phiS)*(1-phiV)))*JSV)+(2*phiV*(1-phiV)*JVV)+(rbinom(ASV,s)));
      
# for AVV immigrants (click train), use
#        ASV=round((2*phiS*(1-phiS)*JSS)+(((phiS*phiV)+((1-phiS)*(1-phiV)))*JSV)+(2*phiV*(1-phiV)*JVV)+(rbinom(ASV,s)));
#        if (t==53){
#            ASS=round((pow(phiS,2)*JSS)+(phiS*(1-phiV)*JSV)+(pow(1-phiV,2)*JVV)+(rbinom(ASS,s)))-im;
#            AVV=im;
#          } 
#          else{
#            ASS=round((pow(phiS,2)*JSS)+(phiS*(1-phiV)*JSV)+(pow(1-phiV,2)*JVV)+(rbinom(ASS,s)));
#            AVV=round((pow(1-phiS,2)*JSS)+((1-phiS)*phiV*JSV)+(pow(phiV,2)*JVV)+(rbinom(AVV,s)));
      
            
# Process model, coded in C-snippets
      SAVS.sim <- "
      double x2 = (ASV+(2*ASS))/(2*(ASS+AVV+ASV));      
      double y2 = ((2*AVV)+ASV)/(2*(ASS+AVV+ASV));
      double phiS = ((1/b)*pow(x2,n))/(pow((1-x2),n)+(1/b)*pow(x2,n));
      double phiV = (b*pow(y2,n))/(pow((1-y2),n)+b*pow(y2,n));
      double ret;
      if (t < 50){
        ret = rpois(33.6);
      } else{
        ret = rpois(33.6-(.182*(t-49)));
      }  
      double e = rbinom(ret,(ASS+AVV)/(ASS+ASV+AVV));
      double f = rbinom(e,ASS/(ASS+AVV));
      
      JSS=round(f);
      JSV=round(ret-e);
      JVV=round(e-f);

        AVV=round((pow(1-phiS,2)*JSS)+((1-phiS)*phiV*JSV)+(pow(phiV,2)*JVV)+(rbinom(AVV,s)));
        if (t==53){
            ASS=round((pow(phiS,2)*JSS)+(phiS*(1-phiV)*JSV)+(pow(1-phiV,2)*JVV)+(rbinom(ASS,s)))-im;
            ASV=im;
          } 
          else{
            ASS=round((pow(phiS,2)*JSS)+(phiS*(1-phiV)*JSV)+(pow(1-phiV,2)*JVV)+(rbinom(ASS,s)));
            ASV=round((2*phiS*(1-phiS)*JSS)+(((phiS*phiV)+((1-phiS)*(1-phiV)))*JSV)+(2*phiV*(1-phiV)*JVV)+(rbinom(ASV,s)));
      
        }
      "
      # Measurement model; dmeas computes probability of sampling variant, rmeas
      # simulates model using this probability
      dmeas <- "
      lik = dbinom(variants,total,AVV/(ASS+ASV+AVV),give_log) + 
            dbinom(standards,total,ASS/(ASS+ASV+AVV),give_log) +
            dbinom(both,total,ASV/(ASS+ASV+AVV),give_log);
      "
      rmeas <- "
      variants = rbinom(total,AVV/(ASS+ASV+AVV));
      standards = rbinom(total,ASS/(ASS+ASV+AVV));
      both = rbinom(total,ASV/(ASS+ASV+AVV));
      "
      # Initialize POMP object
      po <- pomp(data=birdy,times="year",t0=0,
                 rprocess=discrete.time.sim(step.fun=Csnippet(SAVS.sim),delta.t=1),
                 rmeasure=Csnippet(rmeas), dmeasure=Csnippet(dmeas),
                 ## the order of the observations as they appear in the original data structure
                 obsnames=c("standards","both","variants","total"),
                 ## the order of the state variables assumed in the native routines:
                 statenames=c("ASS","ASV","AVV","JSS","JSV","JVV"),
                 ## the order of the parameters assumed in the native routines:
                 paramnames=c('s','b','n','im'))
      
      # Run the simulation
      siml <- simulate(po,params=pars,nsim=1,as.data.frame=TRUE)
      
      coef(po) <- pars
      pf <- pfilter(po,params=pars,Np=2500,max.fail=25)
      
      print(logLik(pf))
      ll = ll + (logLik(pf))
      
siml$totaladults <- (siml$ASS + siml$ASV + siml$AVV)      
StandardRuns <- cbind(StandardRuns,(siml$ASS/siml$totaladults))
VariantRuns <- cbind(VariantRuns,(siml$AVV/siml$totaladults))
BothRuns <- cbind(BothRuns,(siml$ASV/siml$totaladults))

  }

ll = round (ll/50, digits = 2)
ll

# ===============
#  Calculate mean and CI for all runs, get data into format for graphing

StandardRunsData <- data.frame(StandardRuns)
StandardRunsData$mean <- rowMeans(subset(StandardRunsData, select=-c(X1)))
CIs <- apply(as.matrix(subset(StandardRunsData, select=-c(X1))), 1, function(x){mean(x)+c(-1.96,1.96)*sd(x)/sqrt(length(x))})
CIs <-t(CIs)
StandardRunsData <- cbind(StandardRunsData, CIs)
names(StandardRunsData)[names(StandardRunsData)=='1'] <- "lower"
names(StandardRunsData)[names(StandardRunsData)=='2'] <- "upper"
names(StandardRunsData)[names(StandardRunsData)=='X1'] <- "Year"
StandardRunsData[,2:26]<-list(NULL)
StandardRunsData <- add_column(StandardRunsData,Type="Standard", .after="Year")

VariantRunsData <- data.frame(VariantRuns)
VariantRunsData$mean <- rowMeans(subset(VariantRunsData, select=-c(X1)))
CIs <- apply(as.matrix(subset(VariantRunsData, select=-c(X1))), 1, function(x){mean(x)+c(-1.96,1.96)*sd(x)/sqrt(length(x))})
CIs <-t(CIs)
VariantRunsData <- cbind(VariantRunsData, CIs)
names(VariantRunsData)[names(VariantRunsData)=='1'] <- "lower"
names(VariantRunsData)[names(VariantRunsData)=='2'] <- "upper"
names(VariantRunsData)[names(VariantRunsData)=='X1'] <- "Year"
VariantRunsData[,2:26]<-list(NULL)
VariantRunsData <- add_column(VariantRunsData,Type="Variant", .after="Year")

BothRunsData <- data.frame(BothRuns)
BothRunsData$mean <- rowMeans(subset(BothRunsData, select=-c(X1)))
CIs <- apply(as.matrix(subset(BothRunsData, select=-c(X1))), 1, function(x){mean(x)+c(-1.96,1.96)*sd(x)/sqrt(length(x))})
CIs <-t(CIs)
BothRunsData <- cbind(BothRunsData, CIs)
names(BothRunsData)[names(BothRunsData)=='1'] <- "lower"
names(BothRunsData)[names(BothRunsData)=='2'] <- "upper"
names(BothRunsData)[names(BothRunsData)=='X1'] <- "Year"
BothRunsData[,2:26]<-list(NULL)
BothRunsData <- add_column(BothRunsData,Type="Both", .after="Year")

simlgraphdata <- rbind(StandardRunsData, VariantRunsData, BothRunsData)

# ==================================
# And then graph things

ggplot(simlgraphdata,aes(y=mean,x=Year,colour=Type,group=Type)) + 
  scale_color_manual(values=c("purple", "red", "blue"))+
  geom_line(size=1) +
  geom_ribbon(aes(ymin=lower, ymax=upper, fill=factor(Type)), linetype=0, alpha = 0.13)+
  scale_fill_manual(values=c("purple", "red", "blue"))+
  theme_classic()+theme(axis.text=element_text(size=30),
                        axis.title=element_text(size=40))+
  labs(x="\nYear", y="Proportion of Introductions\n")+
  theme(plot.margin=unit(c(1,4,1.5,1.2),"cm"))+
  theme(legend.position="none")+
  ggtitle(paste("log likelihood =", ll, "  selection =", selection,"  bias =", bias, "  immigrants =", immigrants, "\n\n")) 


# ==================================

# Plot the original Kent Island data. 
## To plot three data series with confidence intervals, a data file with a single column is needed
birdycol <- read.csv("IntroTypeCol.csv")
splinedata <- read.csv("SmoothSplines.csv")



ggplot()+
  scale_color_manual(values=c("purple", "red", "blue"))+
  geom_point(data=birdycol, aes(x=Year,y=Proportion,colour=factor(Type),group=Type), size=(birdycol$SampleSize/8), alpha = 0.5) +
  geom_line(data=splinedata, aes(x=Year,y=Proportion,colour=Type,group=Type), size=1) +
  geom_ribbon(data=splinedata,aes(x=Year, ymin=lower, ymax=upper, group=Type, fill=factor(Type)), linetype=0, alpha = 0.13)+
  scale_fill_manual(values=c("purple", "red", "blue"))+
  theme_classic()+theme(axis.text=element_text(size=30),
                        axis.title=element_text(size=40))+
  labs(x="\nYear", y="Proportion of Introductions\n")+
  theme(plot.margin=unit(c(1,4,1.5,2),"cm"))+
  theme(legend.position="none")



